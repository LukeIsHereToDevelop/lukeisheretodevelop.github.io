# command-handler
Command Handler Template.<br>
• discord.js (v12)<br>
• Node.js (v12)<br>
• dotenv (v8.2.0)<br>

# Support us please!
Paypal: r_r_a_a_y_y@yahoo.com / https://paypal.me/ray0001

# FAQ

### I have an issues with this template.
Please create an [issues](https://github.com/Blob-Development/command-handler/issues) if you are having an issues with the template.

### What is your Discord Server?
https://discord.blob-project.com

### How to install discord.js or other packages?
• `npm install discord.js`<br>
• `npm install package-name-whatever-it-is`<br>

### Where I should put my token?
Inside `.env`, replace the `token123213213123213` with your token.

### Is it 100% free open source?
Yes.

### Can I host this on Glitch?
Yeah sure.

### Can you recommend me a good VPS?
Yeah. **Contabo, OVH, DigitalOcean, Vultr, AscendHost**.

### How do I install the node.js?
https://nodejs.org/

### quick.db, doesn't working.
Watch this. https://www.youtube.com/watch?v=-U2-rRxhpx8

# Contributions
Any contributions will be appreciated.
