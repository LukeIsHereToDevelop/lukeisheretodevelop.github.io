module.exports = client => {
  console.log("The bot is ready!");
}
